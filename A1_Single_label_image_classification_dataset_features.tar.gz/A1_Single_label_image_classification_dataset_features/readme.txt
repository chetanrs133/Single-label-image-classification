Image features : image_data_feat_dim60.txt
Image labels : image_data_labels.txt
Label names : meta-data.txt
Feature to Image mapping : feat_2_image_mapping.txt
